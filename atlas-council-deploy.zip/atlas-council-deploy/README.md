# Atlas Council

A Node.js + Express web app that asks connected AI providers for independent answers, runs a cross-model critique round, and asks Chronos (OpenAI) for a balanced final synthesis.

## Important

- This project needs a Node.js server. Opening `public/index.html` directly from your phone or using GitHub Pages will cause `Failed to fetch`, because `/api/status` and `/api/debate` are server endpoints.
- Keep provider API keys private. Add them only in the hosting service's private Environment settings. Never commit `.env`, put keys in `public/`, or send keys in chat.
- Provider API usage may incur charges and provider accounts may have age requirements. Ask a parent/guardian or trusted adult to review and manage provider accounts, API keys, permissions, and spending limits.
- Start with two providers. Each debate makes an initial call and a critique call to each connected provider, plus an OpenAI synthesis call.
- Model IDs change. Set each `*_MODEL` to an exact model ID currently available to that provider account. The app deliberately has no assumed model defaults.

## Deploy on Render

1. Put the contents of this folder at the **root** of your GitHub repository. The root should show `package.json`, `server.js`, `render.yaml`, and `public/` (not just a ZIP file).
2. In Render, choose **New → Blueprint** and connect the GitHub repository.
3. Render reads `render.yaml` and creates the web service. Add the provider API keys and matching model IDs in the service's Environment settings. Do not put secrets in GitHub.
4. Deploy. When the build finishes, open the `onrender.com` URL Render gives you.
5. The page should show connected models. If it shows none, check that both the API key and model ID are set for at least two providers.

## Run locally

1. Install Node.js LTS.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and fill in provider keys and exact model IDs (with an adult managing accounts and spending).
4. Run `npm start` and open `http://localhost:3000`.

## Supported providers

- OpenAI Chat Completions
- Anthropic Messages
- Google Gemini `generateContent`
- DeepSeek Chat Completions
- xAI Chat Completions

Check each provider's current API documentation for model IDs, account access, and pricing before enabling it.
